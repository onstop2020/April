https://github.com/WG21-SG14/SG14/blob/master/SG14/inplace_function.h
